# -*- coding: utf-8 -*-
#!/usr/bin/env python
import serial
import sys
import rospy
from geometry_msgs.msg import Twist

class Getch:
    def __init__(self):
        import tty, sys

    def __call__(self):
        import sys, tty, termios
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch


def talker():
    pub = rospy.Publisher('chatter', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        hello_str = "hello world %s" % rospy.get_time()
        rospy.loginfo(hello_str)
        pub.publish(hello_str)
        rate.sleep()

def getKey():

    getch = Getch()
    print("Starting!")
    print("Introduzca un comnado")
    while True:
    comando = getch()
    if comando == '1':
        sys.exit('exiting')

    print(comando)

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass



